const GHRAB_SW_CONTRACT='ghrab-service-worker-v1';
/* GHRAB service-worker contract v1 · update activation is user-controlled. */
const APP_VERSION = "1.3.46";
const CACHE_NAME = "ghrab-differentiator-v1.3.46";
const CACHE_PREFIXES = ["ghrab-differentiator-v", "diferenciator-"];
const CORE_ASSETS = [
  "./",
  "./index.html",
  "./manifest.webmanifest",
  "./access/access-gate.css",
  "./access/reporter-bootstrap.js",
  "./access/error-reporter.js",
  "./access/error-reporter.css",
  "./access/error-reporter-adapter.js",
  "./modules/office-rich.js",
  "./modules/educational-renderers.js",
  "./modules/map-presets.js",
  "./icons/icon-32.png",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./icons/icon-maskable-512.png",
  "./config/brand-manifest.json",
  "./config/platform-manifest.json",
  "./assets/brand/school-logo.png",
  "./ghrab-platform.consumer.json"
];

self.addEventListener('message', (event) => {
  if (['GHRAB_SKIP_WAITING', 'SKIP_WAITING'].includes(event.data?.type)) self.skipWaiting();
});

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await cache.addAll(CORE_ASSETS);
    const optionalAssets = ["./modules/multimedia.js", "./modules/geojson-engine.js", "./modules/chemistry-engine.js", "./modules/tex-math.js", "./modules/school-cas.js", "./modules/cross-subject-engine.js", "./modules/algorithm-trace-engine.js", "./modules/reaction-engine.js"];
    if (optionalAssets.length) {
      const results = await Promise.allSettled(optionalAssets.map((asset) => cache.add(asset)));
      const failed = results.filter((item) => item.status === 'rejected').length;
      if (failed) console.warn(`[GHRAB SW] ${failed} volitelných assetů nebylo uloženo do offline cache.`);
    }
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys
      .filter((key) => CACHE_PREFIXES.some((prefix) => key.startsWith(prefix)) && key !== CACHE_NAME)
      .map((key) => caches.delete(key)));
    await self.clients.claim();
  })());
});

async function networkFirst(request, fallbackUrl = '') {
  const cache = await caches.open(CACHE_NAME);
  try {
    const response = await fetch(request, { cache: 'no-store' });
    if (!response || !response.ok) throw new Error(`HTTP ${response?.status || 0}`);
    await cache.put(request, response.clone());
    return response;
  } catch (error) {
    const cached = await cache.match(request, { ignoreSearch: true });
    if (cached) return cached;
    if (fallbackUrl) {
      const fallback = await cache.match(fallbackUrl, { ignoreSearch: true });
      if (fallback) return fallback;
    }
    throw error;
  }
}

async function networkOnlyNoStore(request) {
  return fetch(request, { cache: 'no-store' });
}

function isSecurityCriticalRequest(url, scopePath) {
  const relative = url.pathname.slice(scopePath.length);
  return relative === 'runtime-config.js' ||
    relative === 'config/deployment.json' ||
    relative === 'config/deployment.school-server.json' ||
    relative === 'access/deployment-config.js' ||
    relative === 'ghrab/ghrab-platform.js' ||
    relative === 'release-integrity.json' ||
    relative === 'release-integrity.sig' ||
    relative === 'integrity-status.json' ||
    relative.endsWith('/app-guard.js') ||
    relative.endsWith('/access-control.js') ||
    relative.endsWith('/revoked-access.json');
}

async function cacheFirst(request) {
  const cache = await caches.open(CACHE_NAME);
  const cached = await cache.match(request);
  if (cached) return cached;
  const response = await fetch(request);
  if (response?.ok) await cache.put(request, response.clone());
  return response;
}

function isRuntimeRequest(url, scopePath) {
  const relative = url.pathname.slice(scopePath.length);
  return relative === 'runtime-config.js' ||
    relative === 'config/deployment.json' ||
    relative === 'config/deployment.school-server-p0.json' ||
    relative === 'config/deployment.school-server.example.json' ||
    /^(?:api|auth|session|health)(?:\/|$)/.test(relative);
}

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  const scopePath = new URL('./', self.location.href).pathname;
  if (!url.pathname.startsWith(scopePath)) return;
  if (isSecurityCriticalRequest(url, scopePath)) {
    event.respondWith(networkOnlyNoStore(request));
    return;
  }
  if (request.cache === 'no-store' || isRuntimeRequest(url, scopePath)) return;
  if (request.mode === 'navigate') {
    const fallback = new URL(url.pathname.includes('/manual/') ? 'manual/index.html' : 'index.html', self.registration.scope).href;
    event.respondWith(networkFirst(request, fallback));
    return;
  }
  if (url.pathname.endsWith('/manifest.webmanifest') || url.pathname.endsWith('/build-info.json')) {
    event.respondWith(networkFirst(request));
    return;
  }
  event.respondWith(cacheFirst(request));
});

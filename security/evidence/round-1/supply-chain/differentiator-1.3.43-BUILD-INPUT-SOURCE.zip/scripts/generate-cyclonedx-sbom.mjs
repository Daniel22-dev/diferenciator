#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const root=process.cwd();
const outArg=process.argv[2]||`security/sbom/differentiator-${JSON.parse(fs.readFileSync('package.json','utf8')).version}.cdx.json`;
const lock=JSON.parse(fs.readFileSync(path.join(root,'package-lock.json'),'utf8'));
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
function nameFromPath(p,meta){
  if(meta?.name) return meta.name;
  const m=String(p).match(/node_modules\/(.+)$/); if(!m) return pkg.name;
  const parts=m[1].split('/'); return parts[0].startsWith('@')?`${parts[0]}/${parts[1]}`:parts[0];
}
function hashFromSri(sri){
  if(!sri) return [];
  const first=String(sri).split(/\s+/)[0]; const m=first.match(/^(sha(?:256|384|512))-(.+)$/i); if(!m)return [];
  try{return [{alg:m[1].toUpperCase().replace('SHA','SHA-'),content:Buffer.from(m[2],'base64').toString('hex')}]}catch{return []}
}
const components=[];
for(const [p,m] of Object.entries(lock.packages||{})){
  if(!p||!p.startsWith('node_modules/')||!m?.version) continue;
  const name=nameFromPath(p,m); const scope=pkg.devDependencies?.[name]?'optional':'required';
  const purl=`pkg:npm/${encodeURIComponent(name).replace('%40','@').replace('%2F','%2F')}@${m.version}`;
  components.push({type:'library',name,version:String(m.version),purl,scope,hashes:hashFromSri(m.integrity),properties:[{name:'ghrab:lockfilePath',value:p}]});
}
components.sort((a,b)=>a.purl.localeCompare(b.purl,'en'));
const bom={bomFormat:'CycloneDX',specVersion:'1.5',serialNumber:`urn:uuid:${crypto.randomUUID()}`,version:1,metadata:{timestamp:new Date().toISOString(),component:{type:'application',name:pkg.name,version:pkg.version}},components};
fs.mkdirSync(path.dirname(outArg),{recursive:true}); fs.writeFileSync(outArg,JSON.stringify(bom,null,2)+'\n');
console.log(JSON.stringify({status:'PASS',output:outArg,components:components.length,uniquePurl:new Set(components.map(x=>x.purl)).size,withHashes:components.filter(x=>x.hashes.length).length},null,2));

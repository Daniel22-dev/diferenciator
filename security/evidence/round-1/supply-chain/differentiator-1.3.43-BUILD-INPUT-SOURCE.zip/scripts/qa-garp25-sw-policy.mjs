#!/usr/bin/env node
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path'; import {spawnSync} from 'node:child_process';
const root=process.cwd(), checker=path.join(root,'security/garp25/tools/check-sw-security-freeze.mjs'), list=path.join(root,'security/security-critical-assets.json');
const deploy=path.join(root,'dist-school-server'), sw=path.join(deploy,'sw.js');
function run(swPath){return spawnSync(process.execPath,[checker,swPath,deploy,list],{encoding:'utf8'})}
const base=run(sw); const cases=[{id:'baseline',pass:base.status===0,exit:base.status}];
const raw=fs.readFileSync(sw,'utf8'); const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'dpl-garp25-sw-'));
try{
  const p1=path.join(tmp,'sw-precache-critical.js'); fs.writeFileSync(p1,raw.replace('const CORE_ASSETS = [','const CORE_ASSETS = [\n  "./ghrab/ghrab-platform.js",'));
  const r1=run(p1); cases.push({id:'GHNC-SW-PRECACHE-CRITICAL',pass:r1.status!==0,exit:r1.status});
  const p2=path.join(tmp,'sw-no-structural-guard.js'); fs.writeFileSync(p2,raw.replaceAll('isSecurityCriticalRequest','isSecurityCriticalRequest_MUTATED'));
  const r2=run(p2); cases.push({id:'GHNC-SW-GUARD-REMOVED',pass:r2.status!==0,exit:r2.status});
} finally {fs.rmSync(tmp,{recursive:true,force:true})}
const ok=cases.every(c=>c.pass); console[ok?'log':'error'](JSON.stringify({status:ok?'PASS':'FAIL',cases},null,2));process.exit(ok?0:1);

#!/usr/bin/env node
// GARP 2.5.1 - verify explicit AI boundary inventory and fingerprint against source bytes.
import { createHash } from 'node:crypto';
import { readFile, lstat } from 'node:fs/promises';
import path from 'node:path';

const [fingerprintArg, inventoryArg, rootArg='.'] = process.argv.slice(2);
if(!fingerprintArg||!inventoryArg){
  console.error('Usage: node verify-ai-assurance-fingerprint.mjs <fingerprint.json> <inventory.json> [project-root]');
  process.exit(2);
}
const root=path.resolve(rootArg), fingerprint=JSON.parse(await readFile(fingerprintArg,'utf8')), inventoryRaw=JSON.parse(await readFile(inventoryArg,'utf8'));
const errors=[]; const norm=p=>String(p||'').replaceAll('\\','/').replace(/^\.\//,''); const sha=b=>createHash('sha256').update(b).digest('hex');
if(!Array.isArray(inventoryRaw)||!inventoryRaw.length||inventoryRaw.some(x=>typeof x!=='string'||!x.trim())) errors.push('inventory-invalid');
const inventory=[...new Set((Array.isArray(inventoryRaw)?inventoryRaw:[]).map(norm))].sort();
if(inventory.length!==(Array.isArray(inventoryRaw)?inventoryRaw.length:0)) errors.push('inventory-duplicates');
if(!['ghrab-ai-assurance-fingerprint-v2'].includes(fingerprint.schema)) errors.push(`schema:${fingerprint.schema||'missing'}`);
const declared=(fingerprint.files||[]).map(x=>norm(x.path));
if(JSON.stringify(declared)!==JSON.stringify(inventory)) errors.push('inventory-fingerprint-file-list-mismatch');
const rows=[];
for(const rel of inventory){
  const abs=path.resolve(root,rel); if(abs!==root&&!abs.startsWith(root+path.sep)){errors.push(`path-escape:${rel}`);continue;}
  try{
    const st=await lstat(abs); if(!st.isFile()){errors.push(`not-file:${rel}`);continue;}
    const bytes=await readFile(abs), digest=sha(bytes), expected=(fingerprint.files||[]).find(x=>norm(x.path)===rel)?.sha256;
    if(digest!==expected) errors.push(`sha256:${rel}`); rows.push({path:rel,sha256:digest});
  }catch{errors.push(`missing:${rel}`)}
}
const aggregate=sha(Buffer.from(rows.map(r=>`${r.sha256}  ${r.path}`).join('\n')+'\n'));
if(aggregate!==fingerprint.aggregate) errors.push('aggregate-mismatch');
try{const pkg=JSON.parse(await readFile(path.join(root,'package.json'),'utf8'));if(fingerprint.appVersion&&pkg.version!==fingerprint.appVersion)errors.push(`appVersion:${fingerprint.appVersion}:${pkg.version}`)}catch{}
if(errors.length){console.error(JSON.stringify({status:'FAIL',errors,files:rows.length,aggregate,expected:fingerprint.aggregate},null,2));process.exit(1)}
console.log(JSON.stringify({status:'PASS',files:rows.length,aggregate,inventory:path.resolve(inventoryArg)},null,2));
